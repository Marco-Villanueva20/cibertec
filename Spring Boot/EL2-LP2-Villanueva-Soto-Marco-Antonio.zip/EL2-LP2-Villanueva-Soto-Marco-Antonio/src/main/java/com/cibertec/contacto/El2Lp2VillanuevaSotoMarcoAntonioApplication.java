package com.cibertec.contacto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class El2Lp2VillanuevaSotoMarcoAntonioApplication {

	public static void main(String[] args) {
		SpringApplication.run(El2Lp2VillanuevaSotoMarcoAntonioApplication.class, args);
	}

}
