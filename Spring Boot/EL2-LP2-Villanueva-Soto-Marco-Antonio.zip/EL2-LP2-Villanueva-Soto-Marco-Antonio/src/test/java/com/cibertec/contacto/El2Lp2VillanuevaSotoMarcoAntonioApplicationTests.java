package com.cibertec.contacto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class El2Lp2VillanuevaSotoMarcoAntonioApplicationTests {

	@Test
	void contextLoads() {
	}

}
